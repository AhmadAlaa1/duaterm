"""Terminal Quran reader."""
